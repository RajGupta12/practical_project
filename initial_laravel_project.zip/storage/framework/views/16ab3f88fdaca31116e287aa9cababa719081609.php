<?php $__env->startSection('content'); ?>
<div class="content">

    <div class="row">
        <div class="col-lg-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo e(trans('global.edit')); ?> <?php echo e(trans('global.restaurant.title_singular')); ?>

                    <a href="<?php echo e(url('admin/restaurant')); ?>"><button type="button" class="btn btn-danger btn-sm pull-right" title="Click to back"><i class="fa fa-arrow-left" title="Click to refresh filter"></i></button></a>

                </div>
                <div class="panel-body">

                    <form action="<?php echo e(route("admin.restaurant.update", [$restaurant->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                            <label for="name"><?php echo e(trans('global.restaurant.fields.name')); ?>*</label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($restaurant) ? $restaurant->name : '')); ?>">
                            <?php if($errors->has('name')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('name')); ?>

                                </p>
                            <?php endif; ?>
                            <p class="helper-block">
                                <?php echo e(trans('global.restaurant.fields.name_helper')); ?>

                            </p>
                        </div>
                        <div class="form-group <?php echo e($errors->has('code') ? 'has-error' : ''); ?>">
                            <label for="code"><?php echo e(trans('global.restaurant.fields.code')); ?>*</label>
                            <input type="email" id="code" name="code" class="form-control" value="<?php echo e(old('email', isset($restaurant) ? $restaurant->email : '')); ?>">
                            <?php if($errors->has('code')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('code')); ?>

                                </p>
                            <?php endif; ?>
                            <p class="helper-block">
                                <?php echo e(trans('global.restaurant.fields.code_helper')); ?>

                            </p>
                        </div>
                        <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                            <label for="description"><?php echo e(trans('global.restaurant.fields.description')); ?></label>
                            <input type="text" id="description" name="description" class="form-control" value="<?php echo e(old('email', isset($restaurant) ? $restaurant->description : '')); ?>">
                            <?php if($errors->has('description')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('description')); ?>

                                </p>
                            <?php endif; ?>
                            <p class="helper-block">
                                <?php echo e(trans('global.restaurant.fields.description_helper')); ?>

                            </p>
                        </div>
                        <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                            <label for="phone"><?php echo e(trans('global.restaurant.fields.phone')); ?></label>
                            <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('email', isset($restaurant) ? $restaurant->phone : '')); ?>">
                            <?php if($errors->has('phone')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('phone')); ?>

                                </p>
                            <?php endif; ?>
                            <p class="helper-block">
                                <?php echo e(trans('global.restaurant.fields.phone_helper')); ?>

                            </p>
                        </div>
                        <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                            <label for="email"><?php echo e(trans('global.restaurant.fields.email')); ?></label>
                            <input type="text" id="email" name="email" class="form-control" value="<?php echo e(old('email', isset($restaurant) ? $restaurant->email : '')); ?>">
                            <?php if($errors->has('email')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('email')); ?>

                                </p>
                            <?php endif; ?>
                            <p class="helper-block">
                                <?php echo e(trans('global.restaurant.fields.email_helper')); ?>

                            </p>
                        </div>
                        <div class="form-group">
                            <label for="images">Images </label>
                            <div class="images">
                                <?php $__currentLoopData = $restaurant->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img data-toggle="modal" data-target="#exampleModal" class="image" data-id="<?php echo e($value->id); ?>" data-res-id="<?php echo e($restaurant->id); ?>" height="50px" src="<?php echo e(url('image/'.$value->name)); ?>" alt="<?php echo e($value->name); ?>"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="button" data-toggle="modal" data-target="#exampleModal" data-res-id="<?php echo e($restaurant->id); ?>"  class="image btn btn-success btn-sm " title="Add more image"><i class="fa fa-plus" title="Click to refresh filter"></i></button>

                            </div>
                        </div>
                        <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                            <label for="status"><?php echo e(trans('global.restaurant.fields.status')); ?>*
                               <select name="status" id="status" class="form-control" >
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            <?php if($errors->has('status')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('status')); ?>

                                </p>
                            <?php endif; ?>
                            <p class="helper-block">
                                <?php echo e(trans('global.restaurant.fields.status_helper')); ?>

                            </p>
                        </div>
                        <div>
                            <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
                        </div>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update Image</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route("admin.restaurant.update_image")); ?>" method="POST" enctype="multipart/form-data">
        <div class="modal-body">
                <?php echo csrf_field(); ?>
                <div class="form-group ">
                    <label for="rest_image">Image Name </label>
                    <input type="hidden" id="img_id" name="img_id" class="form-control">
                    <input type="hidden" id="rest_id" name="rest_id" class="form-control">
                    <input type="file" id="rest_image" name="rest_image" class="form-control" accept=".png,.jpg,.jpeg">

                </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
        </form>
      </div>
    </div>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
        // $('.images').click(function(){
            $('.image').on('click', function () {
                if($(this).attr('data-id')){
                    $('#exampleModalLabel').text('Update Image');
                }else{
                    $('#exampleModalLabel').text('Add Image');
                }
              $('#img_id').val($(this).attr('data-id'));
              $('#rest_id').val($(this).attr('data-res-id'));

        });
        });
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\initial_laravel_project\resources\views/admin/restaurant/edit.blade.php ENDPATH**/ ?>