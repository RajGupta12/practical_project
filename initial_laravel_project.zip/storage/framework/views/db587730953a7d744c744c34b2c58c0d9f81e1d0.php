<?php $__env->startSection('content'); ?>
<div class="content">

    <div class="row">
        <div class="col-lg-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo e(trans('global.show')); ?> <?php echo e(trans('global.restaurant.title')); ?>

                </div>
                <div class="panel-body">

                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th>
                                    <?php echo e(trans('global.restaurant.fields.name')); ?>

                                </th>
                                <td>
                                    <?php echo e($restaurant->name); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('global.restaurant.fields.email')); ?>

                                </th>
                                <td>
                                    <?php echo e($restaurant->email); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('global.restaurant.fields.description')); ?>

                                </th>
                                <td>
                                    <?php echo e($restaurant->description); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                    <?php echo e(trans('global.restaurant.fields.code')); ?>

                                </th>
                                <td>
                                    <?php echo e($restaurant->code); ?>

                                </td>
                            </tr>
                            <tr>
                                <th>
                                   Image
                                </th>
                                <td>
                                    <?php $__currentLoopData = $restaurant->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <img src="<?php echo e(URL::to('/public/rest_images')); ?>/<?php echo e($value->name); ?>" alt="<?php echo e($value->name); ?>"/>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\initial_laravel_project\resources\views/admin/restaurant/show.blade.php ENDPATH**/ ?>