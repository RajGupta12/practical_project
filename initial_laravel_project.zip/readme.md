just create database "homestead1" and import database file "homestead1.sql".

run command "php artisan serve".

run project using url : http://localhost:8000

username:  admin@admin.com
password:  password